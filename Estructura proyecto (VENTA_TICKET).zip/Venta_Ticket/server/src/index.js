const express = require('express');
const app = express();

// Configuración
app.set('port', 3000); 

// Middleware (funciones que se procesan antes de llegar a rutas)
app.use(express.json()); //Transfomar a formato JSON 

// Rutas (URL)
app.use(require('./routes/usuario'));
app.use(require('./routes/evento'));
app.use(require('./routes/ticket'));
app.use(require('./routes/venta'));
app.use(require('./routes/ticket_venta'));

app.listen(app.get('port'), () => {
     console.log('Servidor en puerto ',app.get('port'))
});
