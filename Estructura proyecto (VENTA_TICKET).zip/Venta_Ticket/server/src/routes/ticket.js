const express = require('express');
const router = express.Router();

const conn = require('../database');

router.get('admin/evento/ticket/:id', (req,res) => {
    const { id } = req.params;
    conn.query('Select * from ticket where id_evento = ?', [id], (err, resp, campos) => {
        if(!err){
            res.json(resp);
        }else{
            console.log(err);
            
        }
    });
});

router.put('/ticket/edit/table', (req,res) => {
    conn.query('ALTER TABLE ticket ADD niveles int(2)', (err, resp, campos) => {
        if(!err){
            res.json({status: 'Campo agregado a la tabla ticket sin problemas...'});
        }else{
            console.log(err);
            
        }
    });
});

router.put('/ticket/update/:id', (req,res) => {
    const { id} = req.params;
    conn.query('UPDATE ticket set id_usuario = 2,disponible = 0 where id_ticket = ?', [id], (err, resp, campos) => {
        if(!err){
            res.json({status: 'ticket(id_usuario,disponible) modificado sin problemas...'});
        }else{
            console.log(err);
            
        }
    });
});


router.put('/ticket/insert', (req,res) => {
    conn.query('INSERT INTO ticket (id_evento,precio,disponible) VALUES (3,1000,"1")', (err, resp, campos) => {
        if(!err){
            res.json({status: 'Ticket insertado a un evento sin problemas...'});
        }else{
            console.log(err);
            
        }
    });
});


router.get('/ticket/fecha', (req,res) => {
    conn.query('SELECT tv.id_ticket, v.fecha FROM ticket_venta as tv INNER JOIN venta as v ON tv.id_venta = v.id_venta WHERE v.fecha = "2020-08-16"', (err, resp, campos) => {
        if(!err){
            res.json(resp);
        }else{
            console.log(err);
            
        }
    });
});


router.get('/comprador/evento/ticket/:id', (req,res) => {
    const { id} = req.params;
    conn.query('Select * FROM ticket WHERE id_evento = ? and disponible = 1', [id], (err, resp, campos) => {
        if(!err){
            res.json(resp);
        }else{
            console.log(err);
            
        }
    });
});

module.exports = router;