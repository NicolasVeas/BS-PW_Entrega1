const express = require('express');
const router = express.Router();

const conn = require('../database');

router.get('/evento', (req,res) => {
    conn.query('Select * from evento', (err, resp, campos) => {
        if(!err){
            res.json(resp);
        }else{
            console.log(err);
            
        }
    });
});

router.get('/evento/:id', (req,res) =>{
    const { id } = req.params;
    conn.query('Select * from evento WHERE id_evento = ?', [id], (err, resp, campos) => {
        if(!err){
            res.json(resp); 
        }else{
            console.log(err);
        }
    });
});


router.post('/evento',(req, res) => {
    conn.query('insert into evento (fecha,hora,nombre,lugar,descripcion,categoria,capacidad) values ("2020-09-18","18:00:00","Mega Ramada 18chera","plaza victoria","Ramadas para celebrar el 18 de septiembre","familiares",20)',(err,resp,campos) =>{
        if(!err) {             
            res.json({status: 'Evento añadido sin problemas...'});
        } else {
            console.log(err);
        }
    });
}); 

router.delete('/evento/:id',(req, res) => {
    const { id } = req.params;
    conn.query('DELETE FROM evento WHERE id_evento = ?', [id],(err,resp,campos) =>{
        if(!err) {            
            res.json({status: 'Evento borrado sin problemas...'});
        } else {
            console.log(err);
        }
    });
}); 

router.put('/evento/:id',(req, res) => {
    const { id } = req.params;
    conn.query('UPDATE evento SET fecha="2020-10-18", hora="19:00:00", lugar="Plaza Vergara", nombre="Mega Ultra Ramada 18chera", categoria="especiales", imagen=null, capacidad=100 WHERE id_evento = ?', [id],(err,resp,campos) =>{
        if(!err) {            
            res.json({status: 'Evento modificado sin problemas...'});
        } else {
            console.log(err);
        }
    });
}); 




module.exports = router;