const express = require('express');
const router = express.Router();

const conn = require('../database');

router.get('/venta', (req,res) => {
    conn.query('SELECT * FROM venta', (err, resp, campos) => {
        if(!err){
            res.json(resp);
        }else{
            console.log(err);
            
        }
    });
});

router.put('/venta/:id',(req, res) => {
    const { id } = req.params;
    conn.query('UPDATE venta SET direccion="Avenida Jose Perez", hora="17:00:00" where id_venta = ?', [id],(err,resp,campos) =>{
        if(!err) {            
            res.json({status: 'datos de la venta modificado sin problemas...'});
        } else {
            console.log(err);
        }
    });
}); 

router.post('/venta',(req, res) => {
    const { id } = req.params;
    conn.query('INSERT INTO venta (monto_total,hora,direccion,fecha) values (3000,"17:00:00","Avenida San Nicolas","2020-08-20")', (err,resp,campos) =>{
        if(!err) {            
            res.json({status: 'Venta insertada sin problemas...'});
        } else {
            console.log(err);
        }
    });
}); 

router.delete('/venta/:id',(req, res) => {
    const { id } = req.params;
    conn.query('DELETE FROM venta WHERE id_venta = ?', [id],(err,resp,campos) =>{
        if(!err) {            
            res.json({status: 'Venta borrada sin problemas...'});
        } else {
            console.log(err);
        }
    });
}); 

router.put('/venta/edit/table', (req,res) => {
    conn.query('ALTER TABLE venta ADD annnoo int(4);', (err, resp, campos) => {
        if(!err){
            res.json({status: 'Campo agregado a la tabla venta sin problemas...'});
        }else{
            console.log(err);
            
        }
    });
});



module.exports = router;
